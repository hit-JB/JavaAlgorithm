create definer = root@localhost trigger new_id
    after insert
    on tao_bao
    for each row
    select new.id into @id_add;

