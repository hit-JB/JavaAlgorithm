create
    definer = root@localhost procedure raisePrice(IN name char, IN textra decimal(8, 2), OUT ototal decimal(8, 2))
begin
    declare total decimal(8,2);
    select sum(price)
    from  tao_bao
        where customer = name
    into total;
    select total + textra /100 * total into ototal;
end;

