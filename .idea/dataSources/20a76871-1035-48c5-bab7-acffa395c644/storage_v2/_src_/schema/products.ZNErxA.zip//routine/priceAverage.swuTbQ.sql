create
    definer = root@localhost procedure priceAverage()
begin
    select AVG(price) as price_average
    from tao_bao;
end;

