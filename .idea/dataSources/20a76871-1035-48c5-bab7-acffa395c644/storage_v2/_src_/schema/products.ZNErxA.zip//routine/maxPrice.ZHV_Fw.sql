create
    definer = root@localhost procedure maxPrice()
begin
    select max(price) as max_price
    from tao_bao;
end;

