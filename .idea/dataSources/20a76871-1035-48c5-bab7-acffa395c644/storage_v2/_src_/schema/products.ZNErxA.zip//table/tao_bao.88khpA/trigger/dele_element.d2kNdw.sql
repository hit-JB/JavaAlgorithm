create definer = root@localhost trigger dele_element
    after delete
    on tao_bao
    for each row
    select OLD.id into @var1;

