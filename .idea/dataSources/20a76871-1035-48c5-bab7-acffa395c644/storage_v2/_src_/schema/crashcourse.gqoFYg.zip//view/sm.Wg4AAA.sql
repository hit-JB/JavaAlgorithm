create view sm as
select `Ec`.`Email` AS `Email`
from (select `crashcourse`.`Person`.`Email` AS `Email`, count(`crashcourse`.`Person`.`Email`) AS `count(Email)`
      from `crashcourse`.`Person`
      group by `crashcourse`.`Person`.`Email`) `Ec`;

