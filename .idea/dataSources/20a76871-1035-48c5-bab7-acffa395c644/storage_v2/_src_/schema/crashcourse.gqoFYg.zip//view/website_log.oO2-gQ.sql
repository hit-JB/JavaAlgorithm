create definer = root@localhost view website_log as
select `crashcourse`.`websites`.`name`    AS `name`,
       `crashcourse`.`websites`.`url`     AS `url`,
       `crashcourse`.`websites`.`id`      AS `id`,
       `crashcourse`.`access_log`.`count` AS `count`
from `crashcourse`.`websites`
         join `crashcourse`.`access_log`
where (`crashcourse`.`websites`.`id` = `crashcourse`.`access_log`.`site_id`);

-- comment on column website_log.name not supported: 站点名称

-- comment on column website_log.count not supported: 访问次数

