create
    definer = root@localhost function getNthHighestSalary(N int) returns int
BEGIN
    set N:=N-1;
    RETURN (
        select
            ifnull((select salary from Employee order by Salary desc limit 1 offset N),
                   null)
    );
END;

